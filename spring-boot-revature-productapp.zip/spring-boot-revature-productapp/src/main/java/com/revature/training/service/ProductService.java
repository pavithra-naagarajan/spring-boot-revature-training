package com.revature.training.service;

import java.util.List;

import com.revature.training.model.Product;

public interface ProductService {
	public boolean addProduct(Product product);
	public boolean deleteProduct(int productId);
	public boolean updateProduct(Product product);
	public Product getProductById(int productId);
	public List<Product> getProductByName(String productName);
	public List<Product> getAllProducts();
	public boolean isProductExists(int productId);

	
	
	
	
	  public List<Product> findByQuantityOnHand(int quantityOnHand);
	  
	  public List<Product> findByQuantityOnHandGreaterThan(int quantityOnHand);
	  public List<Product> findByQuantityOnHandLessThan(int quantityOnHand);
	  
	  public List<Product> findByPriceBetween(int low,int high);
	 
	  
		public List<Product> findByProductNameLikeAndPriceBetween(String productName,int low,int high);

		public List<Product> findByProductNameStartingWithAndPriceBetween(String productName,int low,int high);

}
