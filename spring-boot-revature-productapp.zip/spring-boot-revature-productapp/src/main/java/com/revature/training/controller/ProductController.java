package com.revature.training.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.training.model.Product;

@RestController
@RequestMapping("product")
public class ProductController {
	//get all products
	@GetMapping
	public List<Product> getProducts() {
		System.out.println("All products called!");
		return null;
	}
//get product by name
	@GetMapping("/searchByName/{productName}")
	public List<Product> getProductByName(@PathVariable("productName") String pName) {
		System.out.println("A getProductByName called :" +pName);
		return null;
	}
//get product by id
	@GetMapping("{productId}")
	public List<Product> getProductById(@PathVariable("productId") int pId) {
		System.out.println("A getProductById called "+pId );
		return null;
	}
//insert a product
	@PostMapping
	public String addProduct(@RequestBody Product product) {
		System.out.println("post-Add products called!");
		System.out.println(product);
		return null;
	}
//update a product
	@PutMapping
	public String updateProduct(@RequestBody Product product) {
		System.out.println("Put mapping- products called!");
		System.out.println(product);
		return null;
	}
//delete a product by passing a product object
	@DeleteMapping
	public String deleteProduct(@RequestBody Product product) {
		System.out.println("Delete products called!");
		System.out.println(product);
		return null;
	}
	//delete a product by id
	@DeleteMapping("{productId}")
	public String deleteProductById(@PathVariable("productId") int pId) {
		System.out.println("Delete product By Id called :" +pId);
		
		return null;
	}


}
