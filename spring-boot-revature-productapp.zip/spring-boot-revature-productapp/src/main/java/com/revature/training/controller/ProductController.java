package com.revature.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.training.model.Product;
import com.revature.training.service.ProductService;

@RestController
@RequestMapping("product")
public class ProductController {
	@Autowired
	ProductService productService;

	// get all products
	@GetMapping
	public List<Product> getProducts() {
		System.out.println("All products called!-getmapping");
		List<Product> productList = productService.getAllProducts();
		for (Product p : productList)
			System.out.println(p);
		return productList;
	}

	// get product by name

	@GetMapping("/searchByName/{productName}")
	public List<Product> getProductByName(@PathVariable("productName") String productName) {
		System.out.println("A getProductByName called :" + productName);
		List<Product> productList = productService.getProductByName(productName);
		for (Product p : productList)
			System.out.println(p);
		return productList;
	}

//get product by id
	@GetMapping("{productId}")
	public Product getProductById(@PathVariable("productId") int pId) {
		System.out.println("A getProductById called " + pId);
		Product product = productService.getProductById(pId);
		System.out.println(product);
		return product;

	}

//insert a product
	@PostMapping
	public ResponseEntity<String> addProduct(@RequestBody Product product) {
		ResponseEntity<String> responseEntity=null;
		int productId=product.getProductId();
		String message=null;
		if(productService.isProductExists(productId)) {
		message="Product with productId "+productId+" already exists";
		responseEntity =new ResponseEntity<String>(message,HttpStatus.CONFLICT);
		}
		else {
			productService.addProduct(product);
			message="Product with productId "+productId+" saved successfully";
			responseEntity =new ResponseEntity<String>(message,HttpStatus.CREATED);
		}
		
		System.out.println(product);
		return responseEntity;
		
	}

//update a product
	@PutMapping
	public String updateProduct(@RequestBody Product product) {
		System.out.println("Put mapping- products called!");
		productService.updateProduct(product);

		System.out.println(product);
		return "product updated successfully";
	}

//delete a product by passing a product object
	@DeleteMapping
	public String deleteProduct(@RequestBody Product product) {
		System.out.println("Delete products called!");
		System.out.println(product);
		return null;
	}

	// delete a product by id
	@DeleteMapping("{productId}")
	public String deleteProductById(@PathVariable("productId") int pId) {
		System.out.println("Delete product By Id called :" + pId);
		productService.deleteProduct(pId);

		return "product deleted successfully";

	}

	
	  //custom methods
	  
	//get by quantity
		@GetMapping("/getByQuantity/{quantityOnHand}")
		public List<Product> findByQuantityOnHand(@PathVariable("quantityOnHand") int quantityOnHand) {
			System.out.println("A findByQuantityOnHand called :" + quantityOnHand);
			List<Product> productList = productService.findByQuantityOnHand(quantityOnHand);
			for (Product p : productList)
				System.out.println(p);
			return productList;
		}

		//filter by price
		@GetMapping("/filterByPrice/{low}/{high}")
		public List<Product> findByPriceBetween(@PathVariable("low") int low, @PathVariable("high") int high) {
			System.out.println("A findByPriceBetween called :");
			List<Product> productList = productService.findByPriceBetween(low, high);
			for (Product p : productList)
				System.out.println(p);
			return productList;
		}
		
		
		//quantity greater than
		@GetMapping("/getByQuantityGT/{quantityOnHand}")
		public List<Product> findByQuantityOnHandGreaterThan(@PathVariable("quantityOnHand") int quantityOnHand) {
			System.out.println("A findByQuantityOnHandGreaterThan called :" + quantityOnHand);
			List<Product> productList = productService.findByQuantityOnHandGreaterThan(quantityOnHand);
			for (Product p : productList)
				System.out.println(p);
			return productList;
		}
		
		
		//quantity less than
		@GetMapping("/getByQuantityLT/{quantityOnHand}")
		public List<Product> findByQuantityOnHandLessThan(@PathVariable("quantityOnHand") int quantityOnHand) {
			System.out.println("A findByQuantityOnHandLessThan called :" + quantityOnHand);
			List<Product> productList = productService.findByQuantityOnHandLessThan(quantityOnHand);
			for (Product p : productList)
				System.out.println(p);
			return productList;
		}
		
		
		@GetMapping("/getProductByName/{productName}/range/{low}/{high}")
		public List<Product> findByProductNameLikeAndPriceBetween(@PathVariable("productName") String productName,@PathVariable("low") int low, @PathVariable("high") int high) {
			System.out.println("A findByProductNameLikeAndPriceBetween called ");
			List<Product> productList = productService.findByProductNameLikeAndPriceBetween(productName,low,high);
			for (Product p : productList)
				System.out.println(p);
			return productList;
		}
		
		
		@GetMapping("/getProdByName/{productName}/range/{low}/{high}")
		public List<Product> findByProductNameStartingWithAndPriceBetween(@PathVariable("productName") String productName,@PathVariable("low") int low, @PathVariable("high") int high) {
			System.out.println("A findByProductNameStartingWithAndPriceBetween called ");
			List<Product> productList = productService.findByProductNameStartingWithAndPriceBetween(productName,low,high);
			for (Product p : productList)
				System.out.println(p);
			return productList;
		}
		

}
