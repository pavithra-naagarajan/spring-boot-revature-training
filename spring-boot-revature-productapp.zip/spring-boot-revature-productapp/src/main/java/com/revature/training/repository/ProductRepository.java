package com.revature.training.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.revature.training.model.Product;

public interface ProductRepository extends CrudRepository<Product, Integer> {
	//select * from products where productName=?
	public List<Product> findByProductName(String productName);
	
	public List<Product> findByQuantityOnHand(int quantityOnHand);
	
	public List<Product> findByQuantityOnHandGreaterThan(int quantityOnHand);	
	public List<Product> findByQuantityOnHandLessThan(int quantityOnHand);
	
	public List<Product> findByPriceBetween(int low,int high);
	
	public List<Product> findByProductNameLikeAndPriceBetween(String productName,int low,int high);
	
	public List<Product> findByProductNameStartingWithAndPriceBetween(String productName,int low,int high);

}
