package com.revature.training.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.training.model.Customer;


@RestController
@RequestMapping("customer")
public class CustomerController {
	//get all customers
	@GetMapping
	public List<Customer> getCustomers() {
		System.out.println("Get mapping-All customers called!");
		return null;
	}
//get customer by name
	@GetMapping("/searchByName/{customerName}")
	public List<Customer> getCustomerByName(@PathVariable("customerName") String custName) {
		System.out.println("A getCustomerByName called :" +custName);
		return null;
	}
//get customer by id
	@GetMapping("{customerId}")
	public List<Customer> getCustomerById(@PathVariable("customerId") int custId) {
		System.out.println("A getCustomerById called "+custId );
		return null;
	}
//insert a customer
	@PostMapping
	public String addCustomer(@RequestBody Customer customer) {
		System.out.println("post-Add Customers called!");
		System.out.println(customer);
		return null;
	}
//update a customer
	@PutMapping
	public String updateCustomer(@RequestBody Customer customer) {
		System.out.println("Put mapping- Customers called!");
		System.out.println(customer);
		return null;
	}
//delete a customer by passing a Customer object
	@DeleteMapping
	public String deleteCustomer(@RequestBody Customer customer) {
		System.out.println("Delete customer called!");
		System.out.println(customer);
		return null;
	}
	//delete a customer by id
	@DeleteMapping("{customerId}")
	public String deleteCustomerById(@PathVariable("customerId") int custId) {
		System.out.println("Delete customer By Id called :" +custId);
		
		return null;
	}


}
