package com.revature.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revature.training.model.Product;
import com.revature.training.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepository productRepository;

	@Override
	public boolean addProduct(Product product) {
		System.out.println("##Add product called-service!");
		productRepository.save(product);
		return true;
	}

	@Override
	public boolean deleteProduct(int productId) {
		System.out.println("## delete Product by Id called-service!");
		productRepository.deleteById(productId);
		return true;
	}

	@Override
	public boolean updateProduct(Product product) {
		System.out.println("##Update product called-service!");
		productRepository.save(product);
		return true;
	}

	@Override
	public Product getProductById(int productId) {
		System.out.println("## getProductById called-service!");
		Optional<Product> productData = productRepository.findById(productId);
		Product product = productData.get();
		return product;
	}

	@Override
	public List<Product> getProductByName(String productName) {
		List<Product> productList = (List<Product>) productRepository.findByProductName(productName);
		return productList;

	}

	@Override
	public List<Product> getAllProducts() {
		System.out.println("##get All products called-service!");
		List<Product> productList = (List<Product>) productRepository.findAll();
		return productList;
	}

	@Override
	public boolean isProductExists(int productId) {
		Optional<Product> productData = productRepository.findById(productId);
		return productData.isPresent();
	}


	@Override
	public List<Product> findByQuantityOnHand(int quantityOnHand) {
		List<Product> productList = (List<Product>) productRepository.findByQuantityOnHand(quantityOnHand);
		return productList;
	}

	@Override
	public List<Product> findByQuantityOnHandGreaterThan(int quantityOnHand) {
		List<Product> productList = (List<Product>) productRepository.findByQuantityOnHandGreaterThan(quantityOnHand);
		return productList;
	}

	@Override
	public List<Product> findByQuantityOnHandLessThan(int quantityOnHand) {
		List<Product> productList = (List<Product>) productRepository.findByQuantityOnHandLessThan(quantityOnHand);
		return productList;
	}

	@Override
	public List<Product> findByPriceBetween(int low, int high) {
		List<Product> productList = (List<Product>) productRepository.findByPriceBetween(low, high);
		return productList;
	}

	@Override
	public List<Product> findByProductNameLikeAndPriceBetween(String productName, int low, int high) {
		List<Product> productList = (List<Product>) productRepository.findByProductNameLikeAndPriceBetween(productName, low, high);
		return productList;
	}

	@Override
	public List<Product> findByProductNameStartingWithAndPriceBetween(String productName, int low, int high) {
		List<Product> productList = (List<Product>) productRepository.findByProductNameStartingWithAndPriceBetween(productName, low, high);
		return productList;
	}

	
	
}
