package com.revature.training.conroller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.training.model.Employee;

@RestController
public class HelloController {
	@RequestMapping("/welcome")
	public String getMessage() {
		return "Welcome to spring Boot Project-By Pavithra";
	}
	
	@RequestMapping("/employee")
	public Employee getEmployee() {
		//Employee employee=new Employee(111,"pavithra",45000);
		//return employee;
		return null;
		
	}
	/*
	 * @RequestMapping("/home") public String home() { return
	 * "Welcome to Revature Home Page"; }
	 * 
	 * @RequestMapping("/index") public String index() { return
	 * "Welcome to Index Page"; }
	 * 
	 * @RequestMapping("/product") public String product() { return
	 * "Welcome to product app Page"; }
	 */
}
