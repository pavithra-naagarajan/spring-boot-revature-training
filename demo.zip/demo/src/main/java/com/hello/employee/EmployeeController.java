package com.hello.employee;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.training.model.Employee;

@RestController
public class EmployeeController {
	@RequestMapping("/hello")
	public String hello() {
		
		return "Hello Pavithra!";
		
	}
}